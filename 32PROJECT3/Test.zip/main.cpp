#include "Map.h"
#include <string>
#include <iostream>
#include <cassert>
using namespace std;

int main()
{
        cout << "Enter test number: ";
        int n;
        cin >> n;
        testone(n);
        cout << "Passed" << endl;
}
